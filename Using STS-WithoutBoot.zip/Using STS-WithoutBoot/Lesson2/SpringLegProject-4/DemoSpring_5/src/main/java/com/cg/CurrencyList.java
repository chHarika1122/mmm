package com.cg;

import java.util.ArrayList;

public interface CurrencyList {
	
	public ArrayList<String> getCurrList();

}
