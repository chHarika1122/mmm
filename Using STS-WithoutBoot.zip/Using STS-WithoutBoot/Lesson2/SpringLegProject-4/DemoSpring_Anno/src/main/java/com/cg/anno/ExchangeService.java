package com.cg.anno;

public interface ExchangeService {
	public double getExchangeRate();
}
